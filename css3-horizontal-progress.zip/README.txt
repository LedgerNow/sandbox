A Pen created at CodePen.io. You can find this one at https://codepen.io/Nuwen/pen/NGwEXV.

   This is a combination of two pens:

  CSS3 Horizontal Timeline
  By Peiwen Lu Follow
  http://codepen.io/P233/details/LobqH
  
  Form Progress
  By Robin Brons Follow
  http://codepen.io/bronsrobin/details/dKqcf

Forked from [Peiwen Lu](http://codepen.io/P233/)'s Pen [CSS3 Horizontal Timeline](http://codepen.io/P233/pen/LobqH/).