A Pen created at CodePen.io. You can find this one at https://codepen.io/kjohnson/pen/azBvaE.

 A responsive (vertical and horizontal) semantic (no extra elements for the timeline bar) timeline for [Zenforms](http://zenforms.co), built on [Assembly](http://assembly.com)